import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

const ThreatEscalation = () => {
    const navigate = useNavigate();
    const [countdown, setCountdown] = useState(10);
    const isDispatched = useRef(false);

    useEffect(() => {
        if (countdown > 0) {
            const timer = setInterval(() => setCountdown(c => c - 1), 1000);
            return () => clearInterval(timer);
        }
    }, [countdown]);

    useEffect(() => {
        if (countdown === 0 && !isDispatched.current) {
            isDispatched.current = true;
            const timeout = setTimeout(() => navigate('/alert-confirmation'), 2000);
            return () => clearTimeout(timeout);
        }
    }, [countdown, navigate]);

    return (
        <div className="bg-background-dark text-white min-h-screen font-display flex flex-col items-center justify-center relative overflow-hidden">
            {/* Background Red Pulse */}
            <div className="absolute inset-0 bg-red-600/20 animate-pulse z-0"></div>
            <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(220,38,38,0.4)_0%,rgba(0,0,0,0)_70%)] z-0"></div>

            {/* Content */}
            <main className="relative z-10 w-full max-w-md px-6 text-center space-y-8">

                {/* Icon */}
                <div className="relative inline-block">
                    <div className="absolute inset-0 bg-red-500 rounded-full blur-xl opacity-50 animate-ping"></div>
                    <div className="relative size-24 bg-background-dark border-2 border-red-500 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.6)]">
                        <span className="material-symbols-outlined text-5xl text-red-500">warning</span>
                    </div>
                </div>

                {/* Text */}
                <div className="space-y-2">
                    <h1 className="text-3xl font-bold uppercase tracking-widest text-red-500 drop-shadow-[0_0_10px_rgba(220,38,38,0.8)]">
                        Threat Detected
                    </h1>
                    <p className="text-xl text-white/90 font-medium">
                        Escalating to Emergency Services
                    </p>
                    <p className="text-sm text-white/50 uppercase tracking-wider">
                        High Confidence Threshold Met
                    </p>
                </div>

                {/* Countdown */}
                <div className="py-8">
                    <div className="text-7xl font-bold font-mono nums tabular-nums text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]">
                        00:{countdown.toString().padStart(2, '0')}
                    </div>
                </div>

                {/* Actions */}
                <div className="space-y-4 w-full">
                    <button
                        onClick={() => navigate('/alert-confirmation')}
                        className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl uppercase tracking-widest shadow-[0_0_20px_rgba(220,38,38,0.4)] transition-all active:scale-95"
                    >
                        Dispatch Now
                    </button>

                    <button
                        onClick={() => navigate('/dashboard')}
                        className="w-full bg-transparent border border-white/20 hover:bg-white/10 text-white/70 font-bold py-4 rounded-xl uppercase tracking-widest transition-all"
                    >
                        Cancel Alert
                    </button>
                </div>

                {/* Footer Info */}
                <div className="pt-8 text-[10px] text-white/30 uppercase tracking-widest">
                    Event ID: #TRT-992-AX · Location Locked
                </div>
            </main>

            {/* Scanlines Overlay */}
            <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,20,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-[1] bg-[length:100%_2px,3px_100%] pointer-events-none"></div>
        </div>
    );
};

export default ThreatEscalation;
