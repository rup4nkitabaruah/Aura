import React from 'react';
import { useNavigate } from 'react-router-dom';

const PrivacySettings = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen font-display">
            <div className="relative flex h-full min-h-screen w-full flex-col bg-[linear-gradient(180deg,rgba(25,16,34,1)0%,rgba(10,6,14,1)100%)] overflow-x-hidden max-w-md mx-auto shadow-2xl border-x border-primary/10">
                {/* Top App Bar */}
                <div className="flex items-center p-4 pt-6 justify-between sticky top-0 z-50 bg-background-dark/80 backdrop-blur-md">
                    <div
                        onClick={() => navigate(-1)}
                        className="flex size-10 shrink-0 items-center justify-center rounded-lg border border-primary/30 text-primary cursor-pointer hover:bg-primary/10 transition-colors"
                    >
                        <span className="material-symbols-outlined">arrow_back</span>
                    </div>
                    <h2 className="text-white text-sm font-bold leading-tight tracking-[0.2em] flex-1 text-center uppercase shadow-[0_0_10px_rgba(127,19,236,0.5)]">Aura Terminal</h2>
                    <div className="flex size-10 items-center justify-end text-primary">
                        <span className="material-symbols-outlined">settings_input_component</span>
                    </div>
                </div>

                {/* Main Content */}
                <div className="flex flex-col gap-6 p-4 pb-24">
                    {/* Security Status Header */}
                    <div className="relative group">
                        <div className="absolute -inset-0.5 bg-primary/20 rounded-xl blur opacity-30 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                        <div className="relative flex flex-col items-center justify-center p-8 rounded-xl bg-background-dark border border-primary/30 overflow-hidden">
                            {/* Scanning Ring Effect */}
                            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent opacity-50"></div>
                            <div className="relative z-10 flex flex-col items-center">
                                <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-full border-2 border-primary border-dashed p-4 animate-[spin_10s_linear_infinite]">
                                    <span className="material-symbols-outlined text-5xl text-primary animate-none">shield_lock</span>
                                </div>
                                <p className="text-primary text-[10px] font-bold tracking-[0.3em] uppercase mb-1">Status: Active</p>
                                <h1 className="text-white text-3xl font-bold tracking-tight shadow-[0_0_10px_rgba(127,19,236,0.5)]">SECURE</h1>
                            </div>
                        </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-3 gap-3">
                        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 border border-primary/30">
                            <span className="text-[10px] text-primary/70 uppercase font-bold tracking-widest mb-1">Engine</span>
                            <p className="text-white text-xs font-bold">EDGE-AI</p>
                        </div>
                        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 border border-primary/30">
                            <span className="text-[10px] text-primary/70 uppercase font-bold tracking-widest mb-1">Ciphers</span>
                            <p className="text-white text-xs font-bold">AES-256</p>
                        </div>
                        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 border border-primary/30">
                            <span className="text-[10px] text-primary/70 uppercase font-bold tracking-widest mb-1">Latency</span>
                            <p className="text-white text-xs font-bold">14ms</p>
                        </div>
                    </div>

                    {/* AI Controls Section */}
                    <div className="flex flex-col gap-4">
                        <h3 className="text-primary/60 text-[10px] font-bold tracking-[0.4em] uppercase px-1">AI Logic Controls</h3>
                        {/* Toggle 1 */}
                        <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-primary/40 transition-all cursor-pointer">
                            <div className="flex items-center gap-4">
                                <div className="size-10 flex items-center justify-center rounded-lg bg-primary/20 text-primary">
                                    <span className="material-symbols-outlined">memory</span>
                                </div>
                                <div>
                                    <p className="text-white text-sm font-bold">On-Device Processing</p>
                                    <p className="text-slate-500 text-[10px] uppercase font-medium">Neural engine isolation active</p>
                                </div>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" defaultChecked className="sr-only peer" />
                                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                            </label>
                        </div>
                        {/* Toggle 2 */}
                        <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-primary/40 transition-all cursor-pointer">
                            <div className="flex items-center gap-4">
                                <div className="size-10 flex items-center justify-center rounded-lg bg-primary/20 text-primary">
                                    <span className="material-symbols-outlined">encrypted</span>
                                </div>
                                <div>
                                    <p className="text-white text-sm font-bold">Quantum Encryption</p>
                                    <p className="text-slate-500 text-[10px] uppercase font-medium">End-to-end data tunnel</p>
                                </div>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" defaultChecked className="sr-only peer" />
                                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                            </label>
                        </div>
                        {/* Slider Section */}
                        <div className="p-5 rounded-lg bg-white/5 border border-white/10 flex flex-col gap-4">
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                    <span className="material-symbols-outlined text-primary text-lg">radar</span>
                                    <p className="text-white text-sm font-bold">Alert Sensitivity</p>
                                </div>
                                <span className="text-primary text-xs font-mono font-bold">75%</span>
                            </div>
                            <div className="relative w-full h-8 flex items-center">
                                {/* Custom Segmented Slider */}
                                <div className="flex w-full h-1.5 gap-1">
                                    <div className="flex-1 bg-primary rounded-sm"></div>
                                    <div className="flex-1 bg-primary rounded-sm"></div>
                                    <div className="flex-1 bg-primary rounded-sm"></div>
                                    <div className="flex-1 bg-primary rounded-sm shadow-[0_0_8px_#7f13ec]"></div>
                                    <div className="flex-1 bg-primary/20 rounded-sm"></div>
                                    <div className="flex-1 bg-primary/20 rounded-sm"></div>
                                </div>
                                <div className="absolute left-[65%] size-4 rounded-full bg-white shadow-[0_0_15px_#fff]"></div>
                            </div>
                            <div className="flex justify-between text-[9px] text-slate-500 font-bold uppercase tracking-widest">
                                <span>Passive</span>
                                <span className="text-primary">Optimal</span>
                                <span>Tactical</span>
                            </div>
                        </div>
                    </div>

                    {/* Privacy Matrix Cards */}
                    <div className="flex flex-col gap-4">
                        <h3 className="text-primary/60 text-[10px] font-bold tracking-[0.4em] uppercase px-1">Security Protocols</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 rounded-lg bg-background-dark border border-primary/30 flex flex-col gap-2">
                                <span className="material-symbols-outlined text-primary">android_fingerprint</span>
                                <p className="text-white text-xs font-bold uppercase tracking-tighter">Biometric Lock</p>
                                <p className="text-slate-500 text-[9px]">FaceID / TouchID Active</p>
                            </div>
                            <div className="p-4 rounded-lg bg-background-dark border border-primary/30 flex flex-col gap-2 opacity-50">
                                <span className="material-symbols-outlined text-slate-400">vpn_lock</span>
                                <p className="text-white text-xs font-bold uppercase tracking-tighter">Stealth Mode</p>
                                <p className="text-slate-500 text-[9px]">Inactive in Current Zone</p>
                            </div>
                        </div>
                    </div>

                    {/* Terminal Logs (Decorative) */}
                    <div className="p-4 rounded-lg bg-black/40 border border-white/5 font-mono text-[9px] text-primary/40 h-20 overflow-hidden">
                        <p>&gt; Initializing secure shell...</p>
                        <p>&gt; Handshaking with Aura-Core v2.4.1...</p>
                        <p>&gt; [OK] Memory buffer cleared.</p>
                        <p>&gt; [OK] Local training data encrypted.</p>
                        <p>&gt; Monitoring active threats in 100m radius...</p>
                    </div>
                </div>

                {/* Sticky Footer Action */}
                <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto p-4 bg-background-dark/95 border-t border-primary/20 backdrop-blur-xl">
                    <button
                        onClick={() => navigate('/activation')}
                        className="w-full h-14 bg-primary text-white font-bold tracking-[0.2em] uppercase rounded-lg shadow-[0_0_20px_rgba(127,19,236,0.4)] active:scale-95 transition-all flex items-center justify-center gap-2"
                    >
                        <span className="material-symbols-outlined">restart_alt</span>
                        Recalibrate Aura
                    </button>
                </div>

                {/* Decorative background elements */}
                <div className="fixed top-0 left-0 w-full h-full pointer-events-none overflow-hidden -z-10 opacity-20">
                    <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary rounded-full blur-[120px] mix-blend-screen"></div>
                    <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/40 rounded-full blur-[100px] mix-blend-screen"></div>
                </div>
            </div>
        </div>
    );
};

export default PrivacySettings;
