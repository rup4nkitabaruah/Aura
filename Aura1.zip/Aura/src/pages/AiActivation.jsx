import React from 'react';
import { useNavigate } from 'react-router-dom';

const AiActivation = () => {
    const navigate = useNavigate();

    return (
        <div className="font-display bg-background-light dark:bg-background-dark text-slate-900 dark:text-white min-h-screen flex flex-col">
            {/* Status Bar Area (iOS) */}
            <div className="h-[44px] w-full"></div>

            {/* Top Navigation */}
            <nav className="flex items-center justify-between px-6 py-4">
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-neon-cyan animate-pulse"></div>
                    <span className="text-xs font-bold tracking-widest uppercase text-neon-cyan/80">System Ready</span>
                </div>
                <button
                    onClick={() => navigate('/dashboard')}
                    className="text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-primary transition-colors"
                >
                    Skip
                </button>
            </nav>

            {/* Main Content Container */}
            <main className="flex-1 px-6 pt-4 pb-12 flex flex-col max-w-md mx-auto w-full">
                {/* Header */}
                <header className="mb-10">
                    <h1 className="text-4xl font-bold tracking-tight leading-tight mb-3">
                        Activate <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-neon-cyan">AI Protection</span>
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 text-lg">
                        Empower Aura with the sensors needed to keep you safe in real-time.
                    </p>
                </header>

                {/* Glassmorphic Cards Container */}
                <div className="space-y-4 flex-1">
                    {/* Voice Analysis Card */}
                    <div className="bg-white/5 backdrop-blur-md border border-neon-cyan/20 shadow-lg rounded-xl p-5 flex items-center gap-4 border-l-4 border-l-primary/50">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                            <span className="material-symbols-outlined text-3xl">mic_none</span>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-base">Voice Analysis</h3>
                            <p className="text-xs text-slate-400 leading-relaxed">Listen for distress signals and vocal triggers.</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" defaultChecked className="sr-only peer" />
                            <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>

                    {/* Location Tracking Card */}
                    <div className="bg-white/5 backdrop-blur-md border border-neon-cyan/20 shadow-lg rounded-xl p-5 flex items-center gap-4 border-l-4 border-l-neon-cyan/50">
                        <div className="w-12 h-12 rounded-lg bg-neon-cyan/10 flex items-center justify-center text-neon-cyan">
                            <span className="material-symbols-outlined text-3xl">location_on</span>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-base">Location Tracking</h3>
                            <p className="text-xs text-slate-400 leading-relaxed">Real-time geofencing for emergency response teams.</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" />
                            <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>

                    {/* Motion Sensors Card */}
                    <div className="bg-white/5 backdrop-blur-md border border-neon-cyan/20 shadow-lg rounded-xl p-5 flex items-center gap-4 border-l-4 border-l-primary/50">
                        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                            <span className="material-symbols-outlined text-3xl">motion_sensor_active</span>
                        </div>
                        <div className="flex-1">
                            <h3 className="font-bold text-base">Motion Sensors</h3>
                            <p className="text-xs text-slate-400 leading-relaxed">Detect sudden falls or erratic movement patterns.</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" defaultChecked className="sr-only peer" />
                            <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:bg-primary after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                    </div>
                </div>

                {/* Visual Decorative Element */}
                <div className="my-8 relative h-32 flex items-center justify-center">
                    <div className="absolute inset-0 bg-primary/5 rounded-full blur-3xl"></div>
                    <div className="relative w-24 h-24 border-2 border-primary/20 rounded-full flex items-center justify-center">
                        <div className="w-16 h-16 border border-neon-cyan/30 rounded-full flex items-center justify-center animate-pulse">
                            <span className="material-symbols-outlined text-primary text-4xl">shield_with_heart</span>
                        </div>
                        {/* Scanning line effect */}
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-neon-cyan/50 to-transparent -translate-y-4 opacity-50"></div>
                    </div>
                </div>

                {/* Bottom Action Area */}
                <footer className="mt-auto pt-6">
                    <div className="mb-6 space-y-2">
                        <div className="flex justify-between text-[10px] uppercase tracking-tighter text-slate-500 font-bold">
                            <span>Core Security Setup</span>
                            <span>Step 2 of 3</span>
                        </div>
                        <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full w-2/3 bg-gradient-to-r from-primary to-neon-cyan rounded-full shadow-[0_0_8px_rgba(127,19,236,0.8)]"></div>
                        </div>
                    </div>
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-5 rounded-xl transition-all shadow-[0_0_20px_rgba(127,19,236,0.5)] flex items-center justify-center gap-2 group active:scale-[0.98]"
                    >
                        <span>Enable Aura</span>
                        <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">bolt</span>
                    </button>
                    <p className="text-center text-[11px] text-slate-500 mt-4 leading-normal">
                        Aura AI uses encrypted processing to ensure your data stays private and never leaves your device without an emergency trigger.
                    </p>
                </footer>
            </main>

            {/* Background Decorative Gradient */}
            <div className="fixed top-0 right-0 -z-10 w-64 h-64 bg-primary/10 blur-[100px] rounded-full"></div>
            <div className="fixed bottom-0 left-0 -z-10 w-64 h-64 bg-neon-cyan/5 blur-[100px] rounded-full"></div>
        </div>
    );
};

export default AiActivation;
