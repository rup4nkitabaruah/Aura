import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SplashScreen = () => {
    const navigate = useNavigate();
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress((prev) => {
                if (prev >= 100) {
                    clearInterval(interval);
                    navigate('/dashboard');
                    return 100;
                }
                return prev + 1;
            });
        }, 30); // Adjust speed as needed

        return () => clearInterval(interval);
    }, [navigate]);

    return (
        <div className="relative flex flex-col items-center justify-center min-h-screen w-full bg-[#0a0a0a] overflow-hidden">
            {/* Neural Network Background Pattern */}
            <div className="absolute inset-0 neural-pattern opacity-40"></div>
            {/* Subtle Radial Gradient for Depth */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(127,19,236,0.1)_0%,transparent_70%)]"></div>

            {/* Center Content Branding */}
            <div className="relative z-10 flex flex-col items-center">
                {/* Logo & Aura Ring */}
                <div className="relative flex items-center justify-center w-64 h-64">
                    {/* Outer Aura Ring (Cyan & Purple) */}
                    <div className="absolute inset-0 rounded-full border border-primary/30 aura-glow scale-95 opacity-80"></div>
                    <div className="absolute inset-4 rounded-full border-2 border-neon-cyan/20 scale-100"></div>

                    {/* Minimalist 'A' Logo Container */}
                    <div className="relative flex items-center justify-center w-32 h-32 bg-black/40 backdrop-blur-sm rounded-full border border-white/10">
                        <span className="material-symbols-outlined text-[80px] text-white font-light" style={{ fontVariationSettings: "'wght' 200" }}>
                            change_history
                        </span>
                        {/* Inner glow dot */}
                        <div className="absolute bottom-1/4 w-1.5 h-1.5 bg-neon-cyan rounded-full shadow-[0_0_10px_#00f3ff]"></div>
                    </div>
                </div>

                {/* Brand Name */}
                <h1 className="mt-12 text-5xl font-bold tracking-[0.2em] text-white uppercase">
                    Aura
                </h1>

                {/* Tagline */}
                <p className="mt-4 text-white/60 text-base font-light tracking-widest uppercase">
                    Your Silent AI Guardian
                </p>
            </div>

            {/* Bottom Status/Loading Area */}
            <div className="absolute bottom-16 w-full max-w-[280px] px-8 flex flex-col items-center gap-6">
                {/* Progress Bar Component */}
                <div className="w-full flex flex-col gap-2">
                    <div className="flex justify-between items-end px-1">
                        <span className="text-[10px] text-primary font-medium tracking-widest uppercase">Initializing Protocols</span>
                        <span className="text-[10px] text-white/40">{progress}%</span>
                    </div>
                    <div className="h-[2px] w-full bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-primary to-neon-cyan" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>

                {/* Discreet Security Badge */}
                <div className="flex items-center gap-2 opacity-30">
                    <span className="material-symbols-outlined text-sm text-white">
                        verified_user
                    </span>
                    <span className="text-[10px] text-white tracking-widest uppercase">Encrypted Neural Link Active</span>
                </div>
            </div>

            {/* IOS Home Indicator Placeholder */}
            <div className="absolute bottom-2 w-32 h-1 bg-white/20 rounded-full"></div>

            {/* Decorative UI elements (Corners) */}
            <div className="absolute top-12 left-8 w-8 h-8 border-t border-l border-white/10"></div>
            <div className="absolute top-12 right-8 w-8 h-8 border-t border-r border-white/10"></div>
            <div className="absolute bottom-12 left-8 w-8 h-8 border-b border-l border-white/10 opacity-0 md:opacity-100"></div>
            <div className="absolute bottom-12 right-8 w-8 h-8 border-b border-r border-white/10 opacity-0 md:opacity-100"></div>
        </div>
    );
};

export default SplashScreen;
