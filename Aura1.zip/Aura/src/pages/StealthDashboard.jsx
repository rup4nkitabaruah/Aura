import React from 'react';
import { useNavigate } from 'react-router-dom';

const StealthDashboard = () => {
    const navigate = useNavigate();
    return (
        <div className="relative w-full min-h-screen flex flex-col bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 overflow-x-hidden font-display items-center">
            {/* Main Container (iOS Phone Ratio) */}
            <div className="relative w-full max-w-[430px] h-screen flex flex-col bg-background-light dark:bg-background-dark overflow-hidden">
                {/* Top App Bar */}
                <header className="flex items-center justify-between px-6 pt-12 pb-4 w-full z-20">
                    <div className="flex items-center gap-2">
                        <span className="material-symbols-outlined text-primary text-2xl">shield_locked</span>
                        <span className="text-xs font-bold tracking-[0.2em] uppercase opacity-70">Aura Stealth</span>
                    </div>
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/emergency-network')}
                            className="p-2 rounded-full glass-card border border-white/5 bg-white/5 backdrop-blur-sm"
                        >
                            <span className="material-symbols-outlined text-xl">battery_charging_90</span>
                        </button>
                    </div>
                </header>

                {/* Status Indicator */}
                <div
                    onClick={() => navigate('/activation')}
                    className="flex flex-col items-center justify-center pt-4 z-20 cursor-pointer"
                >
                    <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                        <span className="size-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">AI Monitoring Active</span>
                    </div>
                    <p className="mt-2 text-[10px] opacity-40 uppercase tracking-tighter">Bio-Sync established via secure link</p>
                </div>

                {/* Central AI Core Animation Area */}
                <div className="relative flex-1 flex items-center justify-center w-full z-10">
                    {/* Breathing background gradients */}
                    <div className="absolute inset-0 ai-core-gradient opacity-50 bg-[radial-gradient(circle,rgba(127,19,236,0.4)_0%,rgba(127,19,236,0.1)_40%,transparent_70%)]"></div>

                    {/* Central Orb */}
                    <div className="relative size-64 flex items-center justify-center">
                        {/* Outer Pulse Rings */}
                        <div className="absolute inset-0 rounded-full border border-primary/20 scale-110 opacity-30"></div>
                        <div className="absolute inset-0 rounded-full border border-primary/10 scale-125 opacity-10"></div>

                        {/* Main Orb Visual */}
                        <div className="orb-inner size-48 rounded-full flex items-center justify-center relative overflow-hidden bg-[radial-gradient(circle_at_30%_30%,#7f13ec,#4d0b8f)] shadow-[0_0_60px_10px_rgba(127,19,236,0.4)]">
                            {/* Internal fluid effect */}
                            <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent"></div>
                            {/* Central Icon */}
                            <span className="material-symbols-outlined text-5xl text-white/90">lens_blur</span>
                        </div>

                        {/* Orbiting Data Points (Labels) */}
                        <div className="absolute top-0 right-4 flex flex-col items-end">
                            <span className="text-[10px] opacity-50 uppercase">Analysis</span>
                            <span className="text-sm font-bold">99.2% Stable</span>
                        </div>
                        <div className="absolute bottom-4 left-4 flex flex-col items-start">
                            <span className="text-[10px] opacity-50 uppercase">Neural Link</span>
                            <span className="text-sm font-bold">Encrypted</span>
                        </div>
                    </div>
                </div>

                {/* Real-time Sensor Grid */}
                <div className="px-6 pb-24 grid grid-cols-3 gap-3 w-full z-20">
                    {/* Mic Analysis */}
                    <div className="glass-card rounded-xl p-3 flex flex-col items-center text-center border border-white/5 bg-white/5 backdrop-blur-md">
                        <div className="h-8 flex items-center gap-0.5 mb-2 overflow-hidden">
                            <div className="w-1 h-3 bg-primary/40 rounded-full"></div>
                            <div className="w-1 h-5 bg-primary/60 rounded-full"></div>
                            <div className="w-1 h-2 bg-primary/30 rounded-full"></div>
                            <div className="w-1 h-6 bg-primary rounded-full"></div>
                            <div className="w-1 h-4 bg-primary/70 rounded-full"></div>
                        </div>
                        <span className="material-symbols-outlined text-primary text-xl mb-1">graphic_eq</span>
                        <span className="text-[10px] uppercase font-semibold opacity-60">Acoustic</span>
                        <span className="text-xs font-bold tracking-tight">42 dB Avg</span>
                    </div>

                    {/* Gyroscope */}
                    <div className="glass-card rounded-xl p-3 flex flex-col items-center text-center border border-white/5 bg-white/5 backdrop-blur-md">
                        <div className="size-8 flex items-center justify-center mb-2">
                            <span className="material-symbols-outlined text-primary text-2xl">explore</span>
                        </div>
                        <span className="material-symbols-outlined text-primary text-xl mb-1">screen_rotation</span>
                        <span className="text-[10px] uppercase font-semibold opacity-60">Motion</span>
                        <span className="text-xs font-bold tracking-tight">Stable (X:0)</span>
                    </div>

                    {/* GPS */}
                    <div className="glass-card rounded-xl p-3 flex flex-col items-center text-center border border-white/5 bg-white/5 backdrop-blur-md">
                        <div className="size-8 flex items-center justify-center mb-2">
                            <span className="material-symbols-outlined text-primary text-2xl">satellite_alt</span>
                        </div>
                        <span className="material-symbols-outlined text-primary text-xl mb-1">location_on</span>
                        <span className="text-[10px] uppercase font-semibold opacity-60">Geo-Link</span>
                        <span className="text-xs font-bold tracking-tight">3m Accuracy</span>
                    </div>
                </div>

                {/* Stealth Quick Actions (Discreet bottom dock) */}
                <div className="absolute bottom-0 w-full px-8 pb-10 flex justify-between items-center z-30">
                    <button
                        onClick={() => navigate('/detection')}
                        className="size-10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                    >
                        <span className="material-symbols-outlined">analytics</span>
                    </button>
                    <button
                        onClick={() => navigate('/threat-escalation')}
                        className="size-14 rounded-full glass-card flex items-center justify-center text-primary shadow-lg border border-primary/20 bg-white/5 backdrop-blur-md hover:bg-white/10 transition-colors"
                    >
                        <span className="material-symbols-outlined text-3xl">fingerprint</span>
                    </button>
                    <button
                        onClick={() => navigate('/privacy')}
                        className="size-10 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
                    >
                        <span className="material-symbols-outlined">settings_cinematic_blur</span>
                    </button>
                </div>

                {/* Map Background Detail (Low Opacity for Depth) */}
                <div className="absolute inset-0 pointer-events-none opacity-[0.03] grayscale">
                    <img
                        className="w-full h-full object-cover"
                        src="https://lh3.googleusercontent.com/aida-public/AB6AXuBphPc-VwdbaPIzvrW725vAHgidALoUvkmVt26W1wCpQ4pN4H1ppP-31isVmpFrLCD4CkUZKpL3FvUbWBp0hdYGqtSUUhVEMEmuoKXuO0L9RSDQz1_CpJltd8WZxZhaz-vKxUR_7jHUnxKRPfpTULUkIIGGQQjNFMmIYGJ24-O_FYr8Js4dCnRlEDJTeKr1vD1zAFSUnZXcekTI-0zuoX62YnY8xVBd8yJGaruKG7FpXLJRoaxCsZqdvcoRwiXnV9SYfZUURTG8YxhJ"
                        alt="Map Background"
                    />
                </div>
            </div>

            {/* Decoy Tooltip (Hint for stealth usage) */}
            <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-4 py-2 rounded-lg bg-black/80 text-white text-[10px] uppercase tracking-[0.2em] font-medium border border-white/10 opacity-40">
                Double tap corners to exit stealth
            </div>
        </div>
    );
};

export default StealthDashboard;
