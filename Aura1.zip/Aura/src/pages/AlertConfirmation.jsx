import React from 'react';
import { useNavigate } from 'react-router-dom';

const AlertConfirmation = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white min-h-screen flex justify-center font-display">
            {/* Mobile Container (iPhone Form Factor) */}
            <div className="relative w-full max-w-[430px] min-h-screen flex flex-col bg-background-light dark:bg-background-dark overflow-hidden">
                {/* Top App Bar Component */}
                <div className="flex items-center p-6 pb-2 justify-between">
                    <div
                        onClick={() => navigate(-1)}
                        className="text-primary flex size-10 shrink-0 items-center justify-center rounded-full bg-primary/10 border border-primary/20 cursor-pointer"
                    >
                        <span className="material-symbols-outlined text-[24px]">shield_lock</span>
                    </div>
                    <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-10">Aura Safety</h2>
                </div>

                {/* Success Header */}
                <div className="flex flex-col items-center px-6 pt-8 pb-6">
                    <div className="relative mb-6">
                        {/* Pulsing Glow Effect Simulation */}
                        <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl scale-150 animate-pulse"></div>
                        <div className="relative flex items-center justify-center size-20 rounded-full bg-primary text-white shadow-lg shadow-[0_0_20px_2px_rgba(127,19,236,0.3)]">
                            <span className="material-symbols-outlined text-[40px] font-bold">check_circle</span>
                        </div>
                    </div>
                    <h1 className="text-slate-900 dark:text-white tracking-tight text-[28px] font-bold leading-tight text-center">
                        AI Alert Successfully Dispatched
                    </h1>
                    <p className="text-slate-500 dark:text-[#ad92c9] text-sm mt-2 text-center">Encrypted connection established with emergency centers.</p>
                </div>

                {/* Vertical Timeline Section */}
                <div className="px-8 py-4">
                    <div className="relative">
                        {/* Timeline Grid */}
                        <div className="grid grid-cols-[32px_1fr] gap-x-4">
                            {/* Item 1 */}
                            <div className="flex flex-col items-center">
                                <div className="z-10 flex items-center justify-center size-8 rounded-full bg-primary text-white">
                                    <span className="material-symbols-outlined text-[18px]">android_fingerprint</span>
                                </div>
                                <div className="w-[2px] h-12 bg-gradient-to-b from-[#7f13ec] to-[#362348]"></div>
                            </div>
                            <div className="flex flex-col pt-0.5 pb-8">
                                <p className="text-slate-900 dark:text-white text-base font-semibold leading-none">Stress Detected</p>
                                <p className="text-slate-500 dark:text-[#ad92c9] text-sm font-normal mt-1">Biometric Verification Confirmed</p>
                            </div>

                            {/* Item 2 */}
                            <div className="flex flex-col items-center">
                                <div className="z-10 flex items-center justify-center size-8 rounded-full bg-primary text-white">
                                    <span className="material-symbols-outlined text-[18px]">location_on</span>
                                </div>
                                <div className="w-[2px] h-12 bg-gradient-to-b from-[#7f13ec] to-[#362348]"></div>
                            </div>
                            <div className="flex flex-col pt-0.5 pb-8">
                                <p className="text-slate-900 dark:text-white text-base font-semibold leading-none">GPS Locked</p>
                                <p className="text-slate-500 dark:text-[#ad92c9] text-sm font-normal mt-1">High-Precision Coordinates Shared</p>
                            </div>

                            {/* Item 3 */}
                            <div className="flex flex-col items-center">
                                <div className="z-10 flex items-center justify-center size-8 rounded-full bg-primary text-white">
                                    <span className="material-symbols-outlined text-[18px]">group</span>
                                </div>
                            </div>
                            <div className="flex flex-col pt-0.5">
                                <p className="text-slate-900 dark:text-white text-base font-semibold leading-none">Contacts Notified</p>
                                <p className="text-slate-500 dark:text-[#ad92c9] text-sm font-normal mt-1">3 Emergency Contacts Alerted</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Integration Card */}
                <div className="p-6 mt-auto">
                    <div className="flex flex-col gap-4 rounded-xl bg-slate-100 dark:bg-[#1a1122] border border-slate-200 dark:border-[#362348] p-5 shadow-xl">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <span className="flex size-2 rounded-full bg-green-500 animate-pulse"></span>
                                <p className="text-primary text-xs font-bold tracking-widest uppercase">Active</p>
                            </div>
                            <div className="px-2 py-0.5 rounded bg-primary/20 border border-primary/30 text-[10px] text-primary font-bold">DIRECT LINK</div>
                        </div>
                        <div className="flex gap-4">
                            <div className="flex-1">
                                <h3 className="text-slate-900 dark:text-white text-lg font-bold leading-tight">112 Integration</h3>
                                <p className="text-slate-500 dark:text-[#ad92c9] text-xs font-normal leading-snug mt-1">
                                    Local authorities have received your live audio and location stream.
                                </p>
                            </div>
                            <div className="size-16 rounded-lg overflow-hidden border border-slate-300 dark:border-white/10 shrink-0">
                                <img
                                    className="w-full h-full object-cover opacity-80 contrast-125 grayscale-[0.5]"
                                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCpzfDGzqvLPrVYZRbpMh5JFafNlw5_zvgtTPQIM1GGRR8VHvYofJ_GBhHQSz4Wqqp9RE9XPZemWz7ESnE3cHSOulfQlbnUSLBlzVpPB4yhLa9k2gktdH2agOEZZOtZ0Nieb6n5lGXjliFK9g90kH6sXh9S68x-8lNDbgAxIqdzi4K9lGsliDjvqn2X63c-S4Ta0zPmFYBYG0LzCk5rSrFcpOkmSvxL4vWw_pfQxzB46oS3jxEzxufRnkTw4QOjqiIPznxxwFR-A1Kj"
                                    alt="Map Location"
                                />
                            </div>
                        </div>
                        <button
                            onClick={() => navigate('/emergency-network')}
                            className="w-full flex items-center justify-center gap-2 rounded-lg h-11 bg-slate-200 dark:bg-[#261933] text-slate-700 dark:text-white text-sm font-semibold transition-colors hover:bg-slate-300 dark:hover:bg-[#362348]"
                        >
                            <span>View Dispatch Details</span>
                            <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
                        </button>
                    </div>
                </div>

                {/* Cancel Action (Subtle/Recessed) */}
                <div className="px-6 pb-10 flex flex-col items-center">
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="group flex flex-col items-center gap-2 bg-transparent text-slate-400 dark:text-white/40 hover:text-red-500 dark:hover:text-red-400 transition-colors"
                    >
                        <div className="size-12 flex items-center justify-center rounded-full border-2 border-dashed border-slate-300 dark:border-white/10 group-hover:border-red-500/50">
                            <span className="material-symbols-outlined text-[20px]">close</span>
                        </div>
                        <span className="text-xs font-medium uppercase tracking-widest">Hold to Cancel (False Positive)</span>
                    </button>
                </div>

                {/* Home Indicator (iOS style) */}
                <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-300 dark:bg-white/20 rounded-full"></div>
            </div>
        </div>
    );
};

export default AlertConfirmation;
