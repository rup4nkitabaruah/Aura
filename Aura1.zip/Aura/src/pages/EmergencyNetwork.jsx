import React from 'react';
import { useNavigate } from 'react-router-dom';

const EmergencyNetwork = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white min-h-screen font-display">
            {/* Top Navigation Bar */}
            <div className="sticky top-0 z-50 flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md p-4 justify-between border-b border-white/5">
                <div
                    className="text-primary flex size-10 items-center justify-center cursor-pointer hover:bg-white/5 rounded-full transition-colors"
                    onClick={() => navigate(-1)}
                >
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </div>
                <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center font-display">Trusted AI Network</h2>
                <div className="flex w-10 items-center justify-end">
                    <button className="flex items-center justify-center text-primary hover:text-primary/80 transition-colors">
                        <span className="material-symbols-outlined fill-1">shield_with_heart</span>
                    </button>
                </div>
            </div>

            <main className="max-w-md mx-auto pb-24">
                {/* Network Visualization Hero */}
                <div className="relative h-72 w-full flex items-center justify-center overflow-hidden py-8">
                    {/* Decorative connection lines */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="w-full h-[1px] bg-neon-cyan/20 rotate-[35deg]"></div>
                        <div className="w-full h-[1px] bg-neon-cyan/20 rotate-[-35deg]"></div>
                        <div className="w-[1px] h-full bg-neon-cyan/10"></div>
                    </div>

                    {/* Central Node */}
                    <div className="relative z-10 flex flex-col items-center">
                        <div className="size-24 rounded-full border-2 border-primary/50 p-1 node-glow bg-background-dark shadow-[0_0_20px_rgba(127,19,236,0.4)]">
                            <div
                                className="size-full rounded-full bg-cover bg-center"
                                style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCPvWQkMtKRKhRtOhQ33zMD1aRRGGJb3Bx0CX8d8FO8rFMJg_gfXbOCEvpMhyggHtLnsWhkCPwfrYLVMsMPGNIFXwHIZ33NIY0pLEyh8VEVSTRJweWU8ZgHaZ1KDbBjWrgbt6AhpsYHiEZQ_Z-t-IqvP7v4GixvQeUQKabNl159DMYytKcKY_S760F6hDZ-9xAMhb5OsUCZUTD9tU7Y0uFY4ibc_mUNz__kvu6HIYyzZn6o0jBQBoOVjldynV07fqDQc3-c6a1DxkKv')" }}
                            ></div>
                        </div>
                        <span className="mt-2 text-xs font-bold tracking-[0.2em] text-primary uppercase">User Node</span>
                    </div>

                    {/* Orbiting Contact 1 */}
                    <div className="absolute top-10 left-[15%] flex flex-col items-center">
                        <div className="size-14 rounded-full border border-neon-cyan/30 p-0.5 bg-background-dark">
                            <div
                                className="size-full rounded-full bg-cover bg-center"
                                style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAL18EbJXn73oQ5KfOH-kjQw3Sm21RQlVbRJ9f0CcqDX9pJRESklgK9hB3k-nZ6wcOZ5M1sKi9eyKLznZQ8f1mGSUxuF0F7JolFRuCksllw_6d92AufZYsHCTdC8A4XOfzmoyiUPvQfBFrX8xUaT1wsQDSXV6_myRt0Jg8SxiGSpocd2peqHvMbPW5ounTQCGqQyHqgsHRM7UBdRVAy4gARjqlATOla4dXL0IqqGXK9_i-hnCQZ34bazxlCGSJelevzrnmOTixPOKy6')" }}
                            ></div>
                        </div>
                        <span className="mt-1 text-[10px] text-neon-cyan/80">Sarah</span>
                    </div>

                    {/* Orbiting Contact 2 */}
                    <div className="absolute bottom-12 right-[12%] flex flex-col items-center">
                        <div className="size-16 rounded-full border border-neon-cyan/30 p-0.5 bg-background-dark">
                            <div
                                className="size-full rounded-full bg-cover bg-center"
                                style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBrlA5dHQ3jKuA0a_hHjRQzqCIjDzur1HcqIVfCiRfIM9-h3g-AUSPL5UVwckHhA9-xhiG6lKBM97XunHyKvmkwZKj_D7FDaoczkpQPuNe6nZe_3QJJjUgoq-boVgbsJBGbn6zERfuhTKgBySESTC44NSYCXkhQCycJ1k9nfYUl3ZcdNWBhW1VgKGE2Te65374YQZz7x9nhpSvccCp8d4qVzEYJJ00X7qDYaXpsBYZmDyuv0uV0WynspEdtjBhKQUJUY-qoEphaDi3E')" }}
                            ></div>
                        </div>
                        <span className="mt-1 text-[10px] text-neon-cyan/80">David</span>
                    </div>

                    {/* Orbiting Contact 3 */}
                    <div className="absolute top-16 right-[20%] flex flex-col items-center">
                        <div className="size-12 rounded-full border border-neon-cyan/30 p-0.5 bg-background-dark">
                            <div
                                className="size-full rounded-full bg-cover bg-center"
                                style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCG51uJ64HRhUfSnlsIM2VlWU4ARyTSWHiovoFascXA7NKWq_ZzbSj8QfBdOEGjb1ORiazoUoFqbVeO-cda_Qx0FCeGiLt7wNSXVolLXbqzFcyKF0oBqANPkakRpekqTdENSnJYIb0mQbaUIf-0eEdQGivYCS7tOIIqf-HSn51WiJb36PgpiC3wucklI4Q4oqSkfeI0iaBxsKmRZUCvG4f2KYj-goM0oGh1VuoO56U-ziDIoYk0vDyPvFbzTRHy97Nyn0GcRxuzouqR')" }}
                            ></div>
                        </div>
                        <span className="mt-1 text-[10px] text-neon-cyan/80">Marcus</span>
                    </div>
                </div>

                {/* AI Capabilities Panel */}
                <div className="px-4 mb-8">
                    <div className="bg-white/5 backdrop-blur-md border border-primary/20 p-5 rounded-xl">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="size-8 rounded-lg bg-primary/20 flex items-center justify-center text-primary">
                                <span className="material-symbols-outlined text-xl">psychology</span>
                            </div>
                            <h3 className="text-white font-bold text-base font-display">Autonomous AI Sentinel</h3>
                        </div>
                        <p className="text-slate-400 text-sm leading-relaxed">
                            Aura monitors biometric anomalies and environmental stressors. In critical events, it triggers alerts autonomously if you are unable to reach your device.
                        </p>
                        <div className="mt-4 flex items-center gap-2">
                            <div className="size-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span className="text-[10px] uppercase tracking-widest text-green-500 font-bold">Vigilance Active</span>
                        </div>
                    </div>
                </div>

                {/* Emergency Network Members List */}
                <div className="px-4">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-white text-lg font-bold font-display">Response Members</h3>
                        <span className="text-xs text-primary font-bold cursor-pointer hover:text-primary/80 transition-colors">+ Add Node</span>
                    </div>
                    <div className="space-y-3">
                        {/* Contact Item 1 */}
                        <div className="bg-white/5 backdrop-blur-md border border-primary/20 p-4 rounded-xl flex items-center gap-4">
                            <div className="relative">
                                <div
                                    className="size-12 rounded-full bg-cover bg-center"
                                    style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCFwg_BglRnI8no9RCjaUG14RDM6vKKRgC4uZdgwby-dq5L7bGt4OKQF4U2NJnQFi9iaotAWkAEcAceHswxa_3htdK6saDJkrFv7-k2iMRvunf6suYaHFyd8vd70kINjHVr-aV1A06jw7OQo3B6j8jaZJ-Of4yTwxieP6YswZuyeCoovY1GH_aZIAw70OboL7U5Qdxnnv6d2nq50_dYguhmIdv15sz50xqd2dzBwkPFbJO_kQ_prEtqn6TddFemelMispElhpIwU5P7')" }}
                                ></div>
                                <div className="absolute -bottom-1 -right-1 size-4 bg-green-500 rounded-full border-2 border-background-dark"></div>
                            </div>
                            <div className="flex-1">
                                <p className="text-white font-bold">Sarah Jenkins</p>
                                <p className="text-slate-500 text-xs">Primary Contact • 1.2km away</p>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                                <span className="text-[10px] uppercase text-slate-500 font-bold">Silent Alert</span>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" defaultChecked className="sr-only peer" />
                                    <div className="w-10 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                </label>
                            </div>
                        </div>

                        {/* Contact Item 2 */}
                        <div className="bg-white/5 backdrop-blur-md border border-primary/20 p-4 rounded-xl flex items-center gap-4">
                            <div className="relative">
                                <div
                                    className="size-12 rounded-full bg-cover bg-center"
                                    style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDDb7yOdoH7q4rKA9b1a-oOhXh319AznQ6UKzZ73gm_WVML1m0ojRR3cG3QVfhLExysEA8VhZu0338Aer1bu28K1jMLERWBVy3n1WxlvgcGs7ZdpRf_sSu0fiDiMl7S6CLlCpxe1707kEJSBPAG3JdkPTGiwzcMYoZCfAaJL0BtOTpzTtJb-6xakVM2EQQhifm3jdfg7krFAgXv_7KVu2jFt0g2og6zEEnATJAru6weAOgxW5C_N2uDzKNN1reh_AWlvo7PVmR9E1jI')" }}
                                ></div>
                                <div className="absolute -bottom-1 -right-1 size-4 bg-green-500 rounded-full border-2 border-background-dark"></div>
                            </div>
                            <div className="flex-1">
                                <p className="text-white font-bold">David Chen</p>
                                <p className="text-slate-500 text-xs">Family • 5.8km away</p>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                                <span className="text-[10px] uppercase text-slate-500 font-bold">Silent Alert</span>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" className="sr-only peer" />
                                    <div className="w-10 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                </label>
                            </div>
                        </div>

                        {/* Contact Item 3 */}
                        <div className="bg-white/5 backdrop-blur-md border border-primary/20 p-4 rounded-xl flex items-center gap-4">
                            <div className="relative">
                                <div
                                    className="size-12 rounded-full bg-cover bg-center"
                                    style={{ backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuC1S450yZ-8Y-PXMkG49XJ2NC66NONEkClenAULozcigcXJuxtFnPLtJyMOLZObGhHbi6VgGJfirTI1FwJz_ZOUmzx7TY0_pEnCND-BIRywEhf0Wf54UrAc_WUo9ES0TbdLbPtOPubFnzeyMekJau4YtF0_0dO-AmxZ2lrZyIDN2ADV0O_PTC8xA27aajQSHJIWxulgAaCTkOHAgbOauT9W-2gSsGa0uVNFwijVBpGQFEpmpdZDrWAvSkjL4YcLxyCNK63rPf2h-Xc-')" }}
                                ></div>
                                <div className="absolute -bottom-1 -right-1 size-4 bg-slate-600 rounded-full border-2 border-background-dark"></div>
                            </div>
                            <div className="flex-1">
                                <p className="text-white font-bold">Marcus Thorne</p>
                                <p className="text-slate-500 text-xs">Security Expert • Offline</p>
                            </div>
                            <div className="flex flex-col items-end gap-1">
                                <span className="text-[10px] uppercase text-slate-500 font-bold">Silent Alert</span>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" defaultChecked className="sr-only peer" />
                                    <div className="w-10 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                {/* System Settings Hint */}
                <div className="p-6 mt-4 text-center">
                    <p className="text-slate-500 text-[11px] uppercase tracking-widest font-medium">
                        All alerts are end-to-end encrypted <br /> by the Aura Response Protocol
                    </p>
                </div>
            </main>

            {/* Navigation Tab Bar (iOS Style) */}
            <nav className="fixed bottom-0 left-0 right-0 bg-background-dark/95 backdrop-blur-xl border-t border-white/10 px-6 py-3 pb-8 flex justify-between items-center z-50">
                <div
                    onClick={() => navigate('/detection')}
                    className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors cursor-pointer"
                >
                    <span className="material-symbols-outlined">explore</span>
                    <span className="text-[10px] font-bold uppercase">Map</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-primary cursor-pointer">
                    <span className="material-symbols-outlined fill-1">hub</span>
                    <span className="text-[10px] font-bold uppercase">Network</span>
                </div>
                <div
                    onClick={() => navigate('/threat-escalation')}
                    className="relative -top-8 size-14 rounded-full bg-primary flex items-center justify-center text-white shadow-[0_0_25px_rgba(127,19,236,0.6)] cursor-pointer hover:scale-105 transition-transform"
                >
                    <span className="material-symbols-outlined text-3xl">emergency</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors cursor-pointer">
                    <span className="material-symbols-outlined">analytics</span>
                    <span className="text-[10px] font-bold uppercase">Vitals</span>
                </div>
                <div
                    onClick={() => navigate('/privacy')}
                    className="flex flex-col items-center gap-1 text-slate-500 hover:text-white transition-colors cursor-pointer"
                >
                    <span className="material-symbols-outlined">settings</span>
                    <span className="text-[10px] font-bold uppercase">Vault</span>
                </div>
            </nav>
        </div>
    );
};

export default EmergencyNetwork;
