import React from 'react';
import { useNavigate } from 'react-router-dom';

const DetectionSimulation = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white min-h-screen">
            {/* iOS Top Status Bar Spacer */}
            <div className="h-12 w-full bg-background-light dark:bg-background-dark"></div>

            {/* Top Navigation Bar */}
            <header className="flex items-center px-4 py-3 justify-between sticky top-0 z-50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-primary/10">
                <div
                    onClick={() => navigate(-1)}
                    className="text-primary dark:text-primary flex size-10 items-center justify-center rounded-full hover:bg-primary/10 cursor-pointer"
                >
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </div>
                <div className="flex flex-col items-center">
                    <h1 className="text-sm font-bold tracking-widest uppercase">AI Threat Detection</h1>
                    <div className="flex items-center gap-1.5">
                        <span className="size-2 bg-green-500 rounded-full animate-pulse"></span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium uppercase tracking-tighter">System Active: 0.4ms Latency</span>
                    </div>
                </div>
                <div className="flex size-10 items-center justify-center rounded-full bg-primary/20 text-primary">
                    <span className="material-symbols-outlined text-[22px]">settings_input_component</span>
                </div>
            </header>

            <main className="p-4 space-y-6 max-w-md mx-auto">
                {/* Intro Section */}
                <section className="text-center px-6">
                    <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">
                        Test Aura's neural sensors in a controlled environment.
                        <span className="text-primary font-semibold"> Select a trigger to simulate.</span>
                    </p>
                </section>

                {/* Module 1: Voice Stress */}
                <div className="group relative overflow-hidden rounded-xl bg-white dark:bg-[#261933] border border-primary/20 p-4 transition-all duration-300">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">record_voice_over</span>
                                Voice Stress
                            </h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono uppercase">Sensor ID: V-STRESS-09</p>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">LIVE FEED</span>
                        </div>
                    </div>
                    {/* Visualization Area */}
                    <div className="w-full h-32 bg-slate-100 dark:bg-black/40 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
                        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent_50%,rgba(127,19,236,0.05)_50%)] bg-[size:100%_4px] opacity-30"></div>
                        {/* Mock Waveform */}
                        <div className="flex items-end gap-1 h-12">
                            <div className="w-1 bg-primary/40 h-4"></div>
                            <div className="w-1 bg-primary/60 h-8"></div>
                            <div className="w-1 bg-primary h-12"></div>
                            <div className="w-1 bg-primary/80 h-10"></div>
                            <div className="w-1 bg-primary/40 h-6"></div>
                            <div className="w-1 bg-primary/60 h-8"></div>
                            <div className="w-1 bg-primary h-12"></div>
                            <div className="w-1 bg-primary/40 h-5"></div>
                        </div>
                        <div className="absolute bottom-2 left-2 text-[9px] font-mono text-slate-400">Jitter: 0.02% | Pitch: 210Hz</div>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                        <div className="space-y-1">
                            <p className="text-sm text-slate-600 dark:text-[#ad92c9]">Vocal jitter & cortisol analysis</p>
                            <p className="text-xs font-bold text-slate-400 dark:text-[#ad92c9]/60">CONFIDENCE: 98.4%</p>
                        </div>
                        <button
                            onClick={() => navigate('/alert-confirmation')}
                            className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors whitespace-nowrap"
                        >
                            Simulate
                        </button>
                    </div>
                </div>

                {/* Module 2: Whisper Safe-Word (SIMULATED STATE) */}
                <div className="group relative overflow-hidden rounded-xl bg-white dark:bg-[#261933] shadow-[0_0_20px_rgba(249,115,22,0.3)] border border-orange-500/50 p-4 transition-all duration-300">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-orange-500">campaign</span>
                                Whisper Safe-Word
                            </h3>
                            <p className="text-xs text-orange-500 mt-1 font-mono uppercase">Trigger Detected: [AURA-ALPHA]</p>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] font-mono text-white bg-orange-500 px-2 py-0.5 rounded animate-pulse">THREAT LEVEL: HIGH</span>
                        </div>
                    </div>
                    {/* Visualization Area */}
                    <div className="w-full h-32 bg-orange-500/5 dark:bg-orange-500/10 rounded-lg mb-4 flex flex-col items-center justify-center relative border border-orange-500/20">
                        <span className="material-symbols-outlined text-orange-500 text-4xl mb-2">graphic_eq</span>
                        <div className="text-orange-500 font-mono text-xs text-center px-4">
                            MATCHING PATTERN: 0.992 <br />
                            TIME_STAMP: 12:44:02.01
                        </div>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                        <div className="space-y-1">
                            <p className="text-sm text-orange-500 font-medium">Safe-word recognized via NLP</p>
                            <p className="text-xs font-bold text-orange-500/70">RESPONSE: DISCREET ALERT</p>
                        </div>
                        <button className="bg-orange-500 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider">
                            Reset
                        </button>
                    </div>
                </div>

                {/* Module 3: Suspicious Gesture */}
                <div className="group relative overflow-hidden rounded-xl bg-white dark:bg-[#261933] border border-primary/20 p-4 transition-all duration-300">
                    <div className="flex justify-between items-start mb-4">
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                                <span className="material-symbols-outlined text-primary">accessibility_new</span>
                                Suspicious Gesture
                            </h3>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono uppercase">Camera Matrix: SL-04</p>
                        </div>
                        <div className="text-right">
                            <span className="text-[10px] font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">SCANNING</span>
                        </div>
                    </div>
                    {/* Visualization Area */}
                    <div className="w-full h-48 bg-slate-900 rounded-lg mb-4 relative overflow-hidden border border-white/5">
                        <img
                            alt="Skeleton Tracking"
                            className="w-full h-full object-cover opacity-40 grayscale"
                            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDU7yzTl5RD6fydWpqlrp9GeEm1Fdeg6FrHPJvZbHjQx1_K--JOOruqFK_zWoimWO1AkDxZbOMHHMR9pjJtmo5aMcPVA6SMWk4BGS5amCB8RkIFZ-CPwG8J8GjaFx15sVVaHQrN_ektFGfFkBNetGzdg6rgFj18cQ8h0eha6ENBPBvLeSKc3aIJBuilckQ03eKhVMCsF7pKwW67iMGEDWObD7_6llLJYKpkO9-ODwGffKTkAH5IKzKXWSMR-LwHHmzkbgBgD7skuJrG"
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                            {/* Skeleton SVG Overlay */}
                            <svg className="w-full h-full text-primary/60" viewBox="0 0 100 100">
                                <circle cx="50" cy="20" fill="currentColor" r="3"></circle>
                                <line stroke="currentColor" strokeWidth="1.5" x1="50" x2="50" y1="23" y2="55"></line>
                                <line stroke="currentColor" strokeWidth="1.5" x1="50" x2="35" y1="30" y2="45"></line>
                                <line stroke="currentColor" strokeWidth="1.5" x1="50" x2="65" y1="30" y2="45"></line>
                                <line stroke="currentColor" strokeWidth="1.5" x1="50" x2="40" y1="55" y2="80"></line>
                                <line stroke="currentColor" strokeWidth="1.5" x1="50" x2="60" y1="55" y2="80"></line>
                            </svg>
                        </div>
                        <div className="absolute top-2 left-2 flex flex-col gap-1">
                            <div className="bg-primary/20 backdrop-blur px-1.5 py-0.5 rounded border border-primary/30 text-[8px] font-mono text-primary">ARM_EXT: 0.82</div>
                            <div className="bg-primary/20 backdrop-blur px-1.5 py-0.5 rounded border border-primary/30 text-[8px] font-mono text-primary">KINETIC_VAR: LOW</div>
                        </div>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                        <div className="space-y-1">
                            <p className="text-sm text-slate-600 dark:text-[#ad92c9]">Skeleton pattern recognition</p>
                            <p className="text-xs font-bold text-slate-400 dark:text-[#ad92c9]/60">OBJECTS: 0 | POSES: 1</p>
                        </div>
                        <button className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors">
                            Simulate
                        </button>
                    </div>
                </div>

                {/* Disclaimer Footer */}
                <footer className="pt-4 pb-12">
                    <div className="bg-slate-200/50 dark:bg-white/5 rounded-lg p-3 border border-slate-300 dark:border-white/10">
                        <div className="flex items-start gap-2">
                            <span className="material-symbols-outlined text-sm text-slate-400">info</span>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-relaxed uppercase tracking-tight">
                                AI detection simulated. This interface is for training and demonstration purposes only. Sensors are not operational for actual life-threatening emergencies in demo mode.
                            </p>
                        </div>
                    </div>
                </footer>
            </main>

            {/* Navigation Tab Bar (iOS Style) */}
            <nav className="fixed bottom-0 left-0 right-0 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-xl border-t border-primary/10 px-8 py-3 pb-8 flex justify-between items-center z-50">
                <div
                    onClick={() => navigate('/dashboard')}
                    className="flex flex-col items-center gap-1 text-slate-400 cursor-pointer hover:text-primary"
                >
                    <span className="material-symbols-outlined text-[24px]">shield</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest">Safe</span>
                </div>
                <div className="flex flex-col items-center gap-1 text-primary cursor-pointer">
                    <span className="material-symbols-outlined text-[24px] font-variation-fill">biotech</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest">Demo</span>
                </div>
                <div
                    onClick={() => navigate('/alert-confirmation')}
                    className="flex flex-col items-center gap-1 text-slate-400 cursor-pointer hover:text-primary"
                >
                    <span className="material-symbols-outlined text-[24px]">history</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest">Logs</span>
                </div>
                <div
                    onClick={() => navigate('/privacy')}
                    className="flex flex-col items-center gap-1 text-slate-400 cursor-pointer hover:text-primary"
                >
                    <span className="material-symbols-outlined text-[24px]">person</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest">Profile</span>
                </div>
            </nav>
        </div>
    );
};

export default DetectionSimulation;
