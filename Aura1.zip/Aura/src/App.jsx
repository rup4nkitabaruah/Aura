import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SplashScreen from './pages/SplashScreen';
import StealthDashboard from './pages/StealthDashboard';
import EmergencyNetwork from './pages/EmergencyNetwork';
import AiActivation from './pages/AiActivation';
import PrivacySettings from './pages/PrivacySettings';
import DetectionSimulation from './pages/DetectionSimulation';
import AlertConfirmation from './pages/AlertConfirmation';
import ThreatEscalation from './pages/ThreatEscalation';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SplashScreen />} />
        <Route path="/dashboard" element={<StealthDashboard />} />
        <Route path="/emergency-network" element={<EmergencyNetwork />} />
        <Route path="/activation" element={<AiActivation />} />
        <Route path="/privacy" element={<PrivacySettings />} />
        <Route path="/detection" element={<DetectionSimulation />} />
        <Route path="/alert-confirmation" element={<AlertConfirmation />} />
        <Route path="/threat-escalation" element={<ThreatEscalation />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
